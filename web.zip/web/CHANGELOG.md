# Changelog

# 04 October 2016

- Migrate to webpack 2

# 18 September 2016

- Using `awesome-typescript-loader` instead of `ts-loader`.

# 5 September 2016

- Migration to TS2 and @types

## 1 September 2016

- Using RC6.

## 28 August 2016

- Adding webpack-dashboard.

## 23 August 2016

- Adding HMR support.

## 3 July 2016

- Use html5mode instead of hash navigation.

## 24 June 2016

- Be able to import Component's templates and styles without using require.
